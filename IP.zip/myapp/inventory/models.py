from django.db import models
from phonenumber_field.modelfields import PhoneNumberField


class Product(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=1000, default='')
    supplier = models.CharField(max_length=100, default="Self")
    image = models.ImageField(upload_to='static/', null=True)
    quantity = models.IntegerField(default=0)
    price = models.IntegerField(default=0)


class Supplier(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=1000, default='')
    email = models.CharField(max_length=1000, default='')


class Customer(models.Model):
    name = models.CharField(max_length=100, default=None)
    email = models.EmailField(default=None)
    address = models.CharField(max_length=1000, default=None)
    phone_number = PhoneNumberField(null=False, blank=False, unique=True)
    company = models.CharField(max_length=1000, default=None)


paymentmode = (
    ('Cash on delivery', 'Cash on delivery'),
    ('UPI/Net Banking', 'UPI/Net Banking'),
)

paymentstatus = (
    ('Paid', 'Paid'),
    ('Unpaid', 'Unpaid'),
)

shipstatus = (
    ('Not Shipped', 'Not Shipped'),
    ('Shipped', 'Shipped'),
    ('Delivered', 'Delivered'),
)

deliverystatus = (
    ('Not Delivered', 'Not Delivered'),
    ('Delivered', 'Delivered'),
)

class Shipment(models.Model):
    orderID = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, default=None)
    img = models.CharField(max_length=1000, default=None)
    customername = models.CharField(max_length=100, default=None)
    address = models.CharField(max_length=1000, default=None)
    phone_number = PhoneNumberField(default=None)
    quantity = models.IntegerField(default=1)
    modeoftransaction = models.CharField(max_length=30, choices=paymentmode, default='Cash on delivery')
    payment = models.CharField(max_length=30, choices=paymentstatus, default='Unpaid')
    status = models.CharField(max_length=30, choices=shipstatus, default='Not Shipped')
    gst = models.BooleanField(default=False)
    price = models.IntegerField(default=1)
    invoice = models.BooleanField(default=False)


class Buy(models.Model):
    orderID = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, default=None)
    supplier = models.CharField(max_length=100, default=None)
    img = models.CharField(max_length=1000, default=None)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField(default=0)
    status = models.CharField(max_length=30, choices=deliverystatus, default='Not Delivered')
    payment = models.CharField(max_length=30, choices=paymentstatus, default='Unpaid')
