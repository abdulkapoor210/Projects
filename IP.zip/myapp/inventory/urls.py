from django.urls import path
from . import views


urlpatterns = [
    path('login', views.login, name='login'),
    path('home', views.home, name='home'),
    path('logout', views.logout, name='logout'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('add_products', views.add_products, name='add_products'),
    path('view_products', views.view_products, name='view_products'),
    path('add_supplier', views.add_supplier, name='add_supplier'),
    path('buy', views.buy_products, name='buy_products'),
    path('sell', views.sell_products, name='sell_products'),
    path('shipment', views.shipment, name='shipment'),
    path('view_purchase', views.view_purchase, name='view_purchase'),
    path('bills', views.bills, name='bills'),
    path('payment_made', views.payment_made, name='payment_made'),
    path('make_paid', views.make_paid, name='make_paid'),
    path('add_user', views.add_user, name='add_user'),
    path('view_user', views.view_user, name='add_user'),
    path('customer_products/<str:customer>', views.customer_products, name='customer_products'),
]
