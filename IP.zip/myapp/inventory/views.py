from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.http import JsonResponse
from .models import Product, Supplier, Customer, Shipment, Buy
import smtplib, ssl
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def home(request):
    return render(request, 'homepage.html')


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def login(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        usernm = request.POST['username']
        passwd = request.POST['password']
        user = auth.authenticate(username=usernm, password=passwd)
        if user is not None:
            auth.login(request, user)
            print(2)
            return redirect('home')
        else:
            print(2)
            messages.info(request, "Password doesn't match.")
            return redirect('login')
    else:
        return render(request, 'login.html')


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def logout(request):
    auth.logout(request)
    return redirect('login')


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def dashboard(request):
    if request.user.is_authenticated:
        shipments = Shipment.objects.all()
        not_shipped = 0
        shipped = 0
        delivered = 0
        for shipment in shipments:
            if shipment.status == "Not Shipped":
                not_shipped += 1
            elif shipment.status == "Shipped":
                shipped += 1
            else:
                delivered += 1
        products = Product.objects.all()
        low = 0
        total = 0
        for product in products:
            if product.quantity <= 5:
                low += 1
            total += 1
        buys = Buy.objects.all()
        hand = 0
        way = 0
        for buy in buys:
            if buy.status == "Delivered":
                hand += buy.quantity
            else:
                way += buy.quantity
        return render(request, 'dashboard.html', {"shipped": shipped, "not_shipped": not_shipped, "delivered": delivered, "low": low, "total": total, "hand": hand, "way": way})
    else:
        return redirect('login')


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def add_products(request):
    if request.method == 'POST':
        name = request.POST['product_name']
        description = request.POST['description']
        supplier = request.POST['suppliers']
        image = request.FILES['img']
        price = request.POST['amount']
        new_product = Product(
            name=name,
            description=description,
            supplier=supplier,
            image=image,
            price=price
        )
        new_product.save()
        return redirect('add_products')
    else:
        suppliers = Supplier.objects.all()
        return render(request, 'product-add.html', {"suppliers": suppliers})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def view_products(request):
    tmp = Product.objects.all()
    products = []
    for product in tmp:
        product.image = str(product.image)[7:]
        products.append(product)
    return render(request, 'product-view.html', {'products': products})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def add_supplier(request):
    if request.method == 'POST':
        name = request.POST['supplier_name']
        location = request.POST['supplier_location']
        email = request.POST['email']
        new_supplier = Supplier(
            name=name,
            location=location,
            email=email,
        )
        new_supplier.save()
        return redirect('add_supplier')
    else:
        suppliers = list(Supplier.objects.all())
        for i in range(len(suppliers)):
            products_owned = list(Product.objects.filter(supplier=suppliers[i].name))
            products_string = ""
            for product in products_owned:
                products_string += f"{product.name}, "
            products_string = products_string[:-2]
            suppliers[i].products = products_string
        return render(request, 'supplier-add.html', {"suppliers": suppliers})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def buy_products(request):
    if request.method == 'POST':
        name = request.POST['product']
        quantity = request.POST['quantity']
        supplier = request.POST['supplier']
        status = request.POST['ship']
        product = Product.objects.filter(name=name).first()
        price = int(quantity) * product.price
        img = str(product.image)[7:]
        product.quantity += int(quantity)
        paystatus = request.POST["paystatus"]
        product.save()
        new_buy = Buy(
            name=name,
            supplier=supplier,
            img=img,
            price=price,
            quantity=quantity,
            status=status,
            payment=paystatus
        )
        new_buy.save()
        return redirect('buy_products')
    else:
        products = Product.objects.all()
        suppliers = Supplier.objects.all()
        return render(request, 'buy_products.html', {"products": products, "suppliers": suppliers})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def sell_products(request):
    if request.method == 'POST':
        if "customer_name" in request.POST:
            name = request.POST["customer_name"]
            address = request.POST["address"]
            phone = request.POST["phone"]
            if Customer.objects.filter(phone_number=phone):
                messages.info(request, "Duplicate phone number entry!")
            else: 
                email = request.POST["customer_email"]
                company = request.POST["company"]
                new_customer = Customer(
                    name=name,
                    address=address,
                    phone_number=phone,
                    company=company,
                    email=email
                )
                new_customer.save()
            return redirect('sell_products')
        else:
            phone = request.POST['customer']
            customerdata = Customer.objects.filter(phone_number=phone).first()
            name = request.POST['product']
            quantity = int(request.POST['quantity'])
            product = Product.objects.filter(name=name).first()
            paymentmode = request.POST['paymentmode']
            paystatus = request.POST['paystatus']
            ship = request.POST['ship']
            gst = request.POST.get("gst-on", False)
            price = int(quantity) * product.price
            if gst:
                gst = True
                price += 0.18 * price
            img = str(product.image)[7:]
            if product.quantity >= quantity:
                product.quantity -= quantity
                shipment = Shipment(
                    name=name,
                    img=img,
                    customername=customerdata.name,
                    address=customerdata.address,
                    phone_number=phone,
                    quantity=quantity,
                    modeoftransaction=paymentmode,
                    payment=paystatus,
                    status=ship,
                    gst=gst,
                    price=price
                )
                shipment.save()
                product.save()
                return redirect('sell_products')
            else:
                messages.info(request, "Not enough products to sell")
            return redirect('sell_products')
    else:
        products = Product.objects.all()
        customers = Customer.objects.all()
        return render(request, 'sell_products.html', {"products": products, "customers": customers})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def shipment(request):
    if request.method == "POST":
        id = request.POST["orderid"]
        sender_email = "20i303@psgtech.ac.in"
        shipment = Shipment.objects.filter(orderID=id).first()
        receiver = Customer.objects.filter(phone_number=shipment.phone_number).first()
        receiver_email = receiver.email
        product = Product.objects.filter(name=shipment.name).first()
        message = f'Invoice:\n{receiver.name} - {receiver.phone_number}\n{receiver.address}\n{product.name}\n{product.description}\nPrice/unit: {product.price}\nQuantity: {shipment.quantity}\nPrice: {shipment.price}\nGST: {shipment.gst}'

        port = 587  
        app_password = "kapoor1337#"

        context = ssl.create_default_context()
        try:
            with smtplib.SMTP("smtp.gmail.com", port) as server:
                server.starttls(context=context)
                server.login(sender_email, app_password)
                server.sendmail(sender_email, receiver_email, message)
            shipment.invoice = True
            shipment.save()
            messages.info(request, "Invoice sent!")
        except:
            messages.info(request, "E-mail invalid!")
        return redirect("shipment")
    else:
        shipments = Shipment.objects.all()
        return render(request, "shipment.html", {"shipments": shipments})


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def view_purchase(request):
    buys = Buy.objects.all()
    return render(request, "purchase-received.html", {"buys": buys})


@login_required(login_url="/login")
def bills(request):
    unpaid = Buy.objects.filter(payment="Unpaid")
    paid = Buy.objects.filter(payment="Paid")
    return render(request, 'bills.html', {"paid": paid, "unpaid": unpaid})


@login_required(login_url="/login")
def payment_made(request):
    payments = Buy.objects.filter(payment="Paid")
    return render(request, "payment-made.html", {'payments': payments})


@login_required(login_url="/login")
def customer_products(request, customer):
    products = Shipment.objects.filter(customername=customer)
    response = {"products": [product.name for product in products]}
    return JsonResponse(response)


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def make_paid(request):
    if request.method == "POST":
        id = request.POST["orderid"]
        shipment = Shipment.objects.filter(orderID=id).first()
        shipment.payment = "Paid"
        shipment.save()
        messages.info(request, "Payment status updated!")
        return redirect("shipment")
    

@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def add_user(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        if User.objects.filter(username=username).first():
            messages.info(request, "Username already in use!")
            return redirect("/add_user")
        elif User.objects.filter(email=email).first():
            messages.info(request, "E-mail already in use!")
            return redirect("/add_user")
        else:
            new_user = User.objects.create_user(username=username, email=email, password=password)
            new_user.save()
            messages.info(request, "User added successfully !")
            return redirect("/add_user")
    return render(request, "users-add.html")


@login_required(login_url="/login")
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def view_user(request):
    users = User.objects.all()
    print(dir(users[0]))
    return render(request, 'users-view.html', {"users": users})